use student_self_service;
create table student(registration_number varchar(17) not null unique, first_name varchar(10) not null, last_name varchar(10), contact_number varchar(15)
not null, city varchar(10)not null, 
street varchar(10) not null, house_number INT not null, emergency_contact_number varchar(15), honours INT, Awards INT, enrolled_in varchar(10), grades varchar( 2) not null,
class_number varchar(3), program_id varchar(3),
Primary key(registration_number), foreign key(class_number) references class(room_number), foreign key(program_id) references program(program_id) );


create table program(program_id varchar(10) not null unique,incharge varchar(20) not null, advisor varchar(20) not null, duration INT not null, 
primary key(program_id));

create table course(course_id varchar(10) not null unique,title varchar(20) not null, credits INT not null, program varchar(10) not null, 
primary key(course_id));

create table class(class_number varchar(14) not null unique,course_code varchar(20) not null, lecturer varchar(20) not null, c_time time not null, 
primary key(class_number), foreign key(course_code) references course(course_id));

create table payment(payment_id varchar(14) not null unique,amount INT not null, paid INT not null, student_id varchar(15), 
primary key(payment_id), foreign key(student_id) references student(registration_number));

create table transcript(student_id varchar(15), transcript_id varchar(15), primary key(student_id), foreign key(transcript_id) references student(registration_number));

create table register(student_id varchar(15), course_code varchar(6), foreign key(student_id)  references student(registration_number), 
foreign key(course_code) references course(course_id));

create table apply(student_id varchar(15), program_id varchar(10),
foreign key(student_id) references student(registration_number), foreign key(program_id) references program(program_id));