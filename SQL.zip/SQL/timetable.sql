use timetable;
drop table timetable;
create table timetable(Day varchar(10) not null unique, class varchar(10) not null unique, section varchar(10) not null unique, lecture_time varchar(10)
 not null unique, course_id varchar(10) not null unique, primary key(Day, class, section, lecture_time)

) ;

create table course(course_id varchar(10) not null unique, title varchar(45) not null, credit_hours varchar(5) not null, Day varchar(10) not null unique,
 class varchar(10) not null unique, section varchar(10) not null unique, lecture_time varchar(10) not null unique, primary key(course_id), foreign key(day, class, section, lecture_time)
 references
 timetable(day, class, section, lecture_time) on delete cascade on update cascade);
 
 create table pre_requisite(course_id varchar(10) not null, pre_req varchar(10) not null, foreign key(course_id) references course(course_id)
 on delete restrict);